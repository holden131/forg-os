if app4 > app3:
        print('what wolud you like to do?')
        math = input('division')
        math2 = input('add')
        math3 = input('sub')
        math4 = input('multiplication')
        if math > math2:
            print('this is being worked on lol')
        if math2 > math:
            add = input('add:')
            print('+')
            add2 = input('add:')
            print(add+add2+ERROR)
        if math3 > math2:
            print('this is being worked on lol')
        if math4 > math3:
            print('this is being worked on lol')